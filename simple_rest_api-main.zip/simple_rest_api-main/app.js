const express = require('express');

const di = require('./config/di');
const ProductController = require('./controllers/productController');
const productRoutes = require('./routes/productRoutes');

const app = express();
app.use(express.json());

const productController = new ProductController(di.productService);

app.use('/api/produtos', productRoutes(productController));

module.exports = app;
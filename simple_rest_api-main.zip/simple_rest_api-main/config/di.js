const ProductRepository = require('../repositories/productRepository');
const ProductService = require('../services/productService');

module.exports = {
  productRepository: new ProductRepository(),
  productService: new ProductService(new ProductRepository()),
};
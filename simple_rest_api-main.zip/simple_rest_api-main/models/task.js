class Task {
    constructor(id, title, description, concluded) {
      this.id = id;
      this.title = title;
      this.description = description;
      this.concluded = concluded;
    }
  }
  
  module.exports = Task;
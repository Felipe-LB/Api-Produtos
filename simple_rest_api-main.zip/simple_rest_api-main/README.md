# SIMPLE REST API EXAMPLE

### This is a basic implementation of a REST API to introduce the main concepts of developing a REST API to students in the web development class.

Here are showed the conceps about  resourses and the HTTP methods correct use for develop a CRUD API example.